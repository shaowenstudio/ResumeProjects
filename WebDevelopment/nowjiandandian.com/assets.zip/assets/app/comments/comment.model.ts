export class Comment {
    constructor(public inputComment: string,
                public created?: string,
                public message?: string,
                public commentId?: string) {}
}